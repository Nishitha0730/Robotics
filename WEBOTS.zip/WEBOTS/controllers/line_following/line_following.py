from controller import Robot

def run_robot(robot):
    time_step = 32
    max_speed = 3.14

   
    left_motor = robot.getDevice("left wheel motor")
    right_motor = robot.getDevice("right wheel motor")
    left_motor.setPosition(float("inf"))
    right_motor.setPosition(float("inf"))
    left_motor.setVelocity(0.0)
    right_motor.setVelocity(0.0)
    
    left_ir_0 = robot.getDistanceSensor("ir0")
    left_ir_0.enable(time_step)
    
    left_ir_2 = robot.getDistanceSensor("ir2")
    left_ir_2.enable(time_step)
    
    right_ir_1 = robot.getDistanceSensor("ir1")
    right_ir_1.enable(time_step)

    right_ir_3 = robot.getDistanceSensor("ir3")
    right_ir_3.enable(time_step)


    while robot.step(time_step) != -1:  
        left_speed = max_speed
        right_speed = max_speed
        
        left_ir_value = left_ir_0.getValue()
        left_ir_2_value = left_ir_2.getValue()
        
        right_ir_value = right_ir_1.getValue()
        right_ir_3_value = right_ir_3.getValue()
        
        # print("left: {} right: {} ".format(left_ir_value, right_ir_value))
        
        if (left_ir_value>right_ir_value) and (left_ir_2_value>left_ir_value) and (left_ir_value>6):
            left_speed = -max_speed
        elif (right_ir_value>left_ir_value) and (right_ir_3_value>right_ir_value)and (right_ir_value>6):
            right_speed = -max_speed

        left_motor.setVelocity(left_speed)
        right_motor.setVelocity(right_speed)

if __name__ == "__main__":
    my_robot = Robot()
    run_robot(my_robot)
